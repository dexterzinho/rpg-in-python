"""
personagens.py
==============

Aqui ficam as classes que representam "seres vivos" do jogo.

CONCEITOS DE PYTHON USADOS AQUI:

- `class`: uma classe é um "molde" para criar objetos. `Personagem`
  é o molde geral; cada `Jogador` ou `Inimigo` criado a partir dele
  é um "objeto" (uma instância) com seus próprios valores de vida,
  ataque, etc.

- `__init__`: é o método especial chamado automaticamente quando
  você cria um objeto (ex: `Jogador("Brayan", ...)`). É onde
  definimos os atributos iniciais daquele objeto.

- `self`: representa "este objeto específico". Quando escrevemos
  `self.vida = vida`, estamos dizendo "guarde esse valor de vida
  DENTRO deste personagem específico", e não numa variável solta.
  Isso é o que permite ter vários personagens ao mesmo tempo, cada
  um com sua própria vida, sem se misturarem.

- Herança (`class Jogador(Personagem)`): significa que `Jogador`
  "nasce" de `Personagem` e já ganha de graça tudo que `Personagem`
  tem (vida, ataque, atacar(), receber_dano()...). Isso evita
  escrever a mesma coisa duas vezes (uma para Jogador, outra para
  Inimigo, em inimigos.py).
"""

import random

import config


class Personagem:
    """Classe base: tudo que jogador e inimigo têm em comum."""

    def __init__(self, nome, vida_maxima, ataque, defesa, nivel=1):
        self.nome = nome
        self.vida_maxima = vida_maxima
        self.vida = vida_maxima
        self.ataque = ataque
        self.defesa = defesa
        self.nivel = nivel
        self.xp = 0
        self.xp_necessario = config.XP_BASE_POR_NIVEL * nivel
        self.ouro = 0

        # Efeito temporário de defesa (ativado pela ação "Defender")
        self.defendendo = False

    def esta_vivo(self):
        return self.vida > 0

    def receber_dano(self, dano):
        """Aplica dano a este personagem, nunca deixando a vida negativa."""
        dano = max(dano, 0)
        self.vida = max(self.vida - dano, 0)

    def curar(self, quantidade):
        """Recupera vida sem nunca ultrapassar a vida máxima."""
        self.vida = min(self.vida + quantidade, self.vida_maxima)

    def calcular_dano(self, alvo, bonus_dano=0):
        """
        Fórmula de dano: ataque - defesa, com uma pequena variação
        aleatória para o combate não ficar sempre idêntico, e nunca
        menos que DANO_MINIMO.
        """
        dano_base = (self.ataque + bonus_dano) - alvo.defesa
        variacao = random.randint(-2, 2)
        dano_final = dano_base + variacao
        return max(dano_final, config.DANO_MINIMO)

    def ganhar_xp(self, quantidade):
        """
        Adiciona XP e verifica se o personagem subiu de nível.
        Retorna True se houve level up (para quem chamou poder
        mostrar a mensagem "LEVEL UP!").
        """
        self.xp += quantidade
        subiu_de_nivel = False
        # Um "while" (e não "if") porque, em teoria, XP suficiente
        # poderia fazer o personagem subir mais de um nível de uma vez.
        while self.xp >= self.xp_necessario:
            self.xp -= self.xp_necessario
            self.subir_nivel()
            subiu_de_nivel = True
        return subiu_de_nivel

    def subir_nivel(self):
        self.nivel += 1
        self.xp_necessario = config.XP_BASE_POR_NIVEL * self.nivel
        self.vida_maxima += config.GANHO_VIDA_POR_NIVEL
        self.vida = self.vida_maxima  # cura total ao subir de nível
        self.ataque += config.GANHO_ATAQUE_POR_NIVEL
        self.defesa += config.GANHO_DEFESA_POR_NIVEL


class Jogador(Personagem):
    """
    Jogador herda tudo de Personagem e adiciona o que é exclusivo
    de quem está jogando: classe escolhida, mana, poções, inventário,
    equipamentos e habilidades.
    """

    def __init__(self, nome, dados_classe):
        super().__init__(
            nome=nome,
            vida_maxima=dados_classe["vida"],
            ataque=dados_classe["ataque"],
            defesa=dados_classe["defesa"],
        )
        self.classe = dados_classe["nome"]
        self.mana_maxima = dados_classe.get("mana", 0)
        self.mana = self.mana_maxima
        self.chance_critico = dados_classe.get("chance_critico", 0.1)

        self.pontos_habilidade = 0
        self.habilidades_desbloqueadas = []

        self.pocoes = dict(config.POCOES_INICIAIS)
        self.inventario = {}  # itens comuns que não são poções

        self.equipamentos = {"arma": None, "armadura": None, "acessorio": None}

        self.area_atual = "vila"
        self.areas_desbloqueadas = ["vila", "floresta"]
        self.chefes_derrotados = []

    # ----- Atributos considerando equipamentos -----

    def ataque_total(self, itens):
        """Ataque base + bônus de equipamentos (itens vem de loja.py)."""
        bonus = 0
        for slot in self.equipamentos.values():
            if slot and slot in itens:
                bonus += itens[slot].get("bonus_ataque", 0)
        return self.ataque + bonus

    def defesa_total(self, itens):
        bonus = 0
        for slot in self.equipamentos.values():
            if slot and slot in itens:
                bonus += itens[slot].get("bonus_defesa", 0)
        return self.defesa + bonus

    def chance_critico_total(self, itens):
        bonus = 0.0
        for slot in self.equipamentos.values():
            if slot and slot in itens:
                bonus += itens[slot].get("bonus_critico", 0.0)
        return self.chance_critico + bonus

    # ----- Recursos -----

    def ganhar_ouro(self, quantidade):
        self.ouro += quantidade

    def gastar_ouro(self, quantidade):
        """Retorna True se conseguiu pagar, False se não tinha ouro suficiente."""
        if self.ouro >= quantidade:
            self.ouro -= quantidade
            return True
        return False

    def usar_pocao(self, tipo):
        """
        Usa uma poção do inventário de poções.
        Retorna a quantidade de vida curada, ou None se não tinha a poção.
        """
        if self.pocoes.get(tipo, 0) <= 0:
            return None

        self.pocoes[tipo] -= 1
        cura = CURA_POR_TIPO.get(tipo, 0)
        self.curar(cura)
        return cura

    def regenerar_mana(self):
        self.mana = min(self.mana + config.REGEN_MANA_POR_TURNO, self.mana_maxima)

    def subir_nivel(self):
        """
        Sobrescreve (faz "override" de) o subir_nivel() da classe base
        para também aumentar mana e conceder pontos de habilidade.
        Chamamos super().subir_nivel() primeiro para reaproveitar a
        lógica comum (vida, ataque, defesa) já escrita em Personagem.
        """
        super().subir_nivel()
        if self.mana_maxima > 0:
            self.mana_maxima += config.GANHO_MANA_POR_NIVEL
            self.mana = self.mana_maxima
        self.pontos_habilidade += config.PONTOS_HABILIDADE_POR_NIVEL


# Mapeamento simples usado por usar_pocao(). Fica aqui porque é um
# detalhe pequeno e específico deste arquivo.
CURA_POR_TIPO = {
    "pocao_pequena": config.CURA_POCAO_PEQUENA,
    "pocao_grande": config.CURA_POCAO_GRANDE,
}


def criar_jogador(nome, id_classe, dados_classes):
    """
    Cria um novo Jogador a partir do nome escolhido e dos dados da
    classe (lidos de dados/classes.json). Mantemos essa função fora
    da classe porque ela lida com a "montagem" a partir de dados
    externos (JSON), e não com o comportamento do personagem em si.
    """
    dados_classe = dados_classes[id_classe]
    return Jogador(nome, dados_classe)
