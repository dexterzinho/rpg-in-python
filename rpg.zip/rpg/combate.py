"""
combate.py
==========

O coração do jogo: o loop de batalha por turnos. Alterna entre o
turno do jogador (escolhe uma ação num menu) e o turno do inimigo
(decide sua ação com uma IA simples, ver inimigos.py).

Este módulo importa `habilidades` e `utils`, mas não conhece nada
sobre áreas ou loja — ele só sabe lutar. Isso é "separação de
responsabilidades": cada arquivo cuida de uma coisa.
"""

import random

import config
import utils
from habilidades import usar_habilidade, habilidades_da_classe, mostrar_arvore_habilidades


def batalha(jogador, inimigo, itens, dados_habilidades, pode_fugir=True):
    """
    Executa uma batalha completa entre jogador e inimigo.
    Retorna uma string com o resultado: "vitoria", "derrota" ou "fuga".
    """
    turno = 1
    jogador.defendendo = False

    while jogador.esta_vivo() and inimigo.esta_vivo():
        _mostrar_status_batalha(jogador, inimigo, turno)

        acao = utils.ler_opcao(
            "\n1 - Atacar\n2 - Habilidade\n3 - Defender\n4 - Usar poção\n"
            + ("5 - Fugir\n" if pode_fugir else "")
            + "Escolha: ",
            {"1", "2", "3", "4", "5"} if pode_fugir else {"1", "2", "3", "4"},
        )

        jogador.defendendo = False

        if acao == "1":
            _turno_atacar(jogador, inimigo, itens)
        elif acao == "2":
            _turno_habilidade(jogador, inimigo, dados_habilidades)
        elif acao == "3":
            jogador.defendendo = True
            print("🛡️ Você entrou em posição defensiva!")
        elif acao == "4":
            _turno_pocao(jogador)
        elif acao == "5" and pode_fugir:
            if random.random() < config.CHANCE_FUGA:
                print("🏃 Você fugiu da batalha!")
                return "fuga"
            else:
                print("🏃 Você tentou fugir, mas não conseguiu!")

        if not inimigo.esta_vivo():
            break

        _turno_inimigo(jogador, inimigo)
        jogador.regenerar_mana() if jogador.mana_maxima > 0 else None

        turno += 1

    if jogador.esta_vivo():
        _mostrar_vitoria(jogador, inimigo)
        return "vitoria"
    else:
        print("\n================================")
        print("DERROTA")
        print("\nVocê foi derrotado.")
        return "derrota"


def _mostrar_status_batalha(jogador, inimigo, turno):
    print("\n================================")
    print("BATALHA\n")
    print(jogador.nome)
    print(utils.barra_vida(jogador.vida, jogador.vida_maxima))
    if jogador.mana_maxima > 0:
        print(utils.barra_vida(jogador.mana, jogador.mana_maxima, emoji="🔵"))
    print()
    titulo_inimigo = "👑 " + inimigo.nome if inimigo.eh_chefe else inimigo.nome
    print(titulo_inimigo)
    print(utils.barra_vida(inimigo.vida, inimigo.vida_maxima))
    print(f"\nTurno {turno}")


def _turno_atacar(jogador, inimigo, itens):
    if random.random() < config.CHANCE_ERRO_ATAQUE:
        print("🎯 Você errou o ataque!")
        return

    critico = random.random() < jogador.chance_critico_total(itens)
    dano = jogador.calcular_dano(inimigo, bonus_dano=(jogador.ataque_total(itens) - jogador.ataque))

    if critico:
        dano = int(dano * config.MULTIPLICADOR_CRITICO)
        print("💥 ATAQUE CRÍTICO!")

    inimigo.receber_dano(dano)
    print(f"Você atacou {inimigo.nome} causando {dano} de dano!")


def _turno_habilidade(jogador, inimigo, dados_habilidades):
    disponiveis = [
        id_hab for id_hab in jogador.habilidades_desbloqueadas
        if dados_habilidades[id_hab]["classe"] == jogador.classe
    ]

    if not disponiveis:
        print("❌ Você não possui nenhuma habilidade desbloqueada.")
        return

    print("\n===== HABILIDADES =====")
    for indice, id_hab in enumerate(disponiveis, start=1):
        dados = dados_habilidades[id_hab]
        print(f"{indice} - {dados['nome']} (custo: {dados.get('custo_mana', 0)} mana)")
    print(f"{len(disponiveis) + 1} - Cancelar")

    escolha = utils.ler_numero("Escolha: ", minimo=1, maximo=len(disponiveis) + 1)
    if escolha == len(disponiveis) + 1:
        return

    id_escolhido = disponiveis[escolha - 1]
    sucesso, mensagem, dano = usar_habilidade(jogador, id_escolhido, inimigo, dados_habilidades)
    print(mensagem)
    if sucesso and dano:
        print(f"Causou {dano} de dano!")


def _turno_pocao(jogador):
    pocoes_disponiveis = {tipo: qtd for tipo, qtd in jogador.pocoes.items() if qtd > 0}

    if not pocoes_disponiveis:
        print("❌ Você não possui poções.")
        return

    print("\n===== POÇÕES =====")
    lista = list(pocoes_disponiveis.items())
    for indice, (tipo, qtd) in enumerate(lista, start=1):
        nome = "Poção pequena" if tipo == "pocao_pequena" else "Poção grande"
        print(f"{indice} - {nome} x{qtd}")
    print(f"{len(lista) + 1} - Cancelar")

    escolha = utils.ler_numero("Escolha: ", minimo=1, maximo=len(lista) + 1)
    if escolha == len(lista) + 1:
        return

    tipo_escolhido = lista[escolha - 1][0]
    cura = jogador.usar_pocao(tipo_escolhido)
    if cura:
        print(f"Você recuperou {cura} de vida!")


def _turno_inimigo(jogador, inimigo):
    acao = inimigo.decidir_acao()

    if acao == "defender":
        inimigo.defendendo = True
        print(f"\n🛡️ {inimigo.nome} entrou em posição defensiva!")
        return

    if random.random() < config.CHANCE_ERRO_ATAQUE:
        print(f"\n🎯 {inimigo.nome} errou o ataque!")
        return

    critico = random.random() < inimigo.chance_critico
    dano = inimigo.calcular_dano(jogador)

    if critico:
        dano = int(dano * config.MULTIPLICADOR_CRITICO)

    if jogador.defendendo:
        dano = int(dano * config.REDUCAO_DANO_DEFENDER)

    jogador.receber_dano(dano)

    if critico:
        print(f"\n💥 {inimigo.nome} acertou um CRÍTICO em você! ({dano} de dano)")
    else:
        print(f"\n{inimigo.nome} atacou você causando {dano} de dano!")


def _mostrar_vitoria(jogador, inimigo):
    print("\n⚔️ Vitória!")
    print(f"Inimigo derrotado: {inimigo.nome}")

    ouro = inimigo.ouro_sorteado()
    jogador.ganhar_ouro(ouro)
    print(f"+{inimigo.xp_concedido} XP")
    print(f"💰 +{ouro} ouro")

    subiu_nivel = jogador.ganhar_xp(inimigo.xp_concedido)
    if subiu_nivel:
        print(f"\n🎉 LEVEL UP! Nível {jogador.nivel}!")

    if inimigo.eh_chefe and inimigo.id not in jogador.chefes_derrotados:
        jogador.chefes_derrotados.append(inimigo.id)
