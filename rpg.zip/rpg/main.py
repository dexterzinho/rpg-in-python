"""
main.py
=======

Ponto de entrada do jogo. Este arquivo NÃO contém regras de jogo —
ele só chama funções dos outros módulos na ordem certa. Se um dia
main.py estivesse com centenas de linhas de lógica de combate ou de
loja, seria sinal de que algo deveria estar em outro arquivo.
"""

import json

import config
import utils
import save
from personagens import criar_jogador
from inimigos import carregar_dados_inimigos
from habilidades import carregar_dados_habilidades, mostrar_arvore_habilidades, desbloquear_habilidade, habilidades_da_classe
from loja import carregar_dados_itens, abrir_loja, equipar_item
from areas import carregar_dados_areas, explorar, verificar_desbloqueios


def carregar_todos_os_dados():
    """Carrega todos os JSONs uma única vez no início do jogo."""
    with open(config.CAMINHO_CLASSES, "r", encoding="utf-8") as arquivo:
        dados_classes = json.load(arquivo)
    return {
        "classes": dados_classes,
        "inimigos": carregar_dados_inimigos(),
        "habilidades": carregar_dados_habilidades(),
        "itens": carregar_dados_itens(),
        "areas": carregar_dados_areas(),
    }


def novo_jogo(dados):
    utils.titulo("NOVO JOGO")
    nome = utils.ler_texto_nao_vazio("Nome do personagem: ")

    print("\n===== ESCOLHA SUA CLASSE =====")
    ids_classes = list(dados["classes"].keys())
    for indice, id_classe in enumerate(ids_classes, start=1):
        info = dados["classes"][id_classe]
        print(f"\n{indice} - {info['nome']}")
        print(f"   Vida: {info['vida']} | Ataque: {info['ataque']} | Defesa: {info['defesa']}")
        if info.get("mana", 0) > 0:
            print(f"   Mana: {info['mana']}")
        print(f"   Chance de crítico: {int(info['chance_critico'] * 100)}%")

    escolha = utils.ler_numero("\nEscolha: ", minimo=1, maximo=len(ids_classes))
    id_classe = ids_classes[escolha - 1]

    jogador = criar_jogador(nome, id_classe, dados["classes"])
    print(f"\n✅ Personagem {jogador.nome} ({jogador.classe}) criado!")
    return jogador


def carregar_ou_criar(dados):
    if save.existe_save():
        print("\n⚠️ Já existe um jogo salvo.")
        escolha = utils.ler_opcao("Deseja começar um novo jogo?\n1 - Sim\n2 - Não\nEscolha: ", {"1", "2"})
        if escolha == "2":
            jogador = save.carregar_jogo()
            if jogador:
                print("✅ Jogo carregado!")
                return jogador
    return novo_jogo(dados)


def menu_personagem(jogador):
    print("\n===== PERSONAGEM =====")
    print(f"Nome: {jogador.nome}")
    print(f"Classe: {jogador.classe}")
    print(f"Nível: {jogador.nivel}")
    print(f"XP: {jogador.xp}/{jogador.xp_necessario}")
    print(f"\nVida: {jogador.vida}/{jogador.vida_maxima}")
    print(f"Ataque: {jogador.ataque}")
    print(f"Defesa: {jogador.defesa}")
    if jogador.mana_maxima > 0:
        print(f"Mana: {jogador.mana}/{jogador.mana_maxima}")
    print(f"\nOuro: {jogador.ouro}")
    print(f"Pontos de habilidade: {jogador.pontos_habilidade}")
    print("\nEquipamentos:")
    print(f"  Arma: {jogador.equipamentos['arma'] or '-'}")
    print(f"  Armadura: {jogador.equipamentos['armadura'] or '-'}")
    print(f"  Acessório: {jogador.equipamentos['acessorio'] or '-'}")
    utils.pausar()


def menu_inventario(jogador, dados_itens):
    print("\n===== INVENTÁRIO =====")
    for tipo, qtd in jogador.pocoes.items():
        if qtd > 0:
            nome = "Poção pequena" if tipo == "pocao_pequena" else "Poção grande"
            print(f"{nome} x{qtd}")
    for id_item, qtd in jogador.inventario.items():
        nome = dados_itens.get(id_item, {}).get("nome", id_item)
        print(f"{nome} x{qtd}")

    equipaveis = [i for i in jogador.inventario if dados_itens.get(i, {}).get("tipo") in ("arma", "armadura", "acessorio")]
    if equipaveis:
        print("\nDeseja equipar algum item?")
        for indice, id_item in enumerate(equipaveis, start=1):
            print(f"{indice} - {dados_itens[id_item]['nome']}")
        print(f"{len(equipaveis) + 1} - Voltar")
        escolha = utils.ler_numero("Escolha: ", minimo=1, maximo=len(equipaveis) + 1)
        if escolha != len(equipaveis) + 1:
            sucesso, mensagem = equipar_item(jogador, equipaveis[escolha - 1], dados_itens)
            print(mensagem)
    utils.pausar()


def menu_habilidades(jogador, dados_habilidades):
    mostrar_arvore_habilidades(jogador, dados_habilidades)
    disponiveis = list(habilidades_da_classe(jogador.classe, dados_habilidades).keys())

    escolha = utils.ler_opcao("\nDesbloquear alguma habilidade? (s/n): ", {"s", "n"})
    if escolha == "n":
        return

    for indice, id_hab in enumerate(disponiveis, start=1):
        print(f"{indice} - {dados_habilidades[id_hab]['nome']}")
    numero = utils.ler_numero("Escolha: ", minimo=1, maximo=len(disponiveis))
    sucesso, mensagem = desbloquear_habilidade(jogador, disponiveis[numero - 1], dados_habilidades)
    print(mensagem)
    utils.pausar()


def tela_derrota(jogador, dados):
    print("\n1 - Voltar para a vila\n2 - Carregar último save\n3 - Sair")
    escolha = utils.ler_opcao("Escolha: ", {"1", "2", "3"})
    if escolha == "1":
        jogador.vida = jogador.vida_maxima
        jogador.area_atual = "vila"
        return jogador
    elif escolha == "2":
        carregado = save.carregar_jogo()
        return carregado if carregado else jogador
    else:
        return None


def loop_principal(jogador, dados):
    while True:
        print("\n================================")
        print("RPG\n")
        print(f"Jogador: {jogador.nome}")
        print(f"Classe: {jogador.classe}")
        print(f"Nível: {jogador.nivel}")
        print(utils.barra_vida(jogador.vida, jogador.vida_maxima))
        print(f"💰 {jogador.ouro} ouro")

        print("\n1 - Explorar\n2 - Personagem\n3 - Inventário\n4 - Habilidades\n5 - Loja\n6 - Salvar\n7 - Sair")
        escolha = utils.ler_opcao("Escolha: ", {"1", "2", "3", "4", "5", "6", "7"})

        if escolha == "1":
            resultado = explorar(jogador, dados["areas"], dados["inimigos"], dados["habilidades"], dados["itens"])
            novas_areas = verificar_desbloqueios(jogador, dados["areas"])
            for nome_area in novas_areas:
                print(f"\n🔓 Nova área desbloqueada: {nome_area}!")
            if resultado in ("vitoria", "evento", "nada", "fuga"):
                save.salvar_jogo(jogador)
            elif resultado == "derrota":
                jogador = tela_derrota(jogador, dados)
                if jogador is None:
                    return
        elif escolha == "2":
            menu_personagem(jogador)
        elif escolha == "3":
            menu_inventario(jogador, dados["itens"])
        elif escolha == "4":
            menu_habilidades(jogador, dados["habilidades"])
            save.salvar_jogo(jogador)
        elif escolha == "5":
            abrir_loja(jogador, dados["itens"])
            save.salvar_jogo(jogador)
        elif escolha == "6":
            if save.salvar_jogo(jogador):
                print("💾 Jogo salvo!")
        elif escolha == "7":
            print("Até a próxima!")
            return


def main():
    dados = carregar_todos_os_dados()

    utils.titulo("RPG")
    print("1 - Novo jogo\n2 - Carregar jogo\n3 - Sair")
    escolha = utils.ler_opcao("Escolha: ", {"1", "2", "3"})

    if escolha == "3":
        return
    elif escolha == "2":
        jogador = save.carregar_jogo()
        if jogador is None:
            print("❌ Nenhum jogo salvo encontrado.")
            jogador = novo_jogo(dados)
        else:
            print("✅ Jogo carregado!")
    else:
        jogador = carregar_ou_criar(dados)

    loop_principal(jogador, dados)


if __name__ == "__main__":
    main()
