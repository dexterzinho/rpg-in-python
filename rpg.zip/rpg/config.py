"""
config.py
=========

Valores e configurações gerais do jogo, centralizados aqui para
evitar "números mágicos" espalhados pelo código (ex: escrever "100"
direto dentro de combate.py sem explicação nenhuma do que significa).

Se um dia quiser mudar o balanceamento do jogo (ex: poções curando
mais, ou o XP necessário por nível), é só mexer aqui.
"""

# ----- Caminhos dos arquivos de dados -----
CAMINHO_SAVE = "dados/save.json"
CAMINHO_INIMIGOS = "dados/inimigos.json"
CAMINHO_HABILIDADES = "dados/habilidades.json"
CAMINHO_ITENS = "dados/itens.json"
CAMINHO_CLASSES = "dados/classes.json"
CAMINHO_AREAS = "dados/areas.json"

# ----- Poções -----
CURA_POCAO_PEQUENA = 30
CURA_POCAO_GRANDE = 60
POCOES_INICIAIS = {"pocao_pequena": 2}

# ----- Combate -----
CHANCE_ERRO_ATAQUE = 0.05          # 5% de chance de errar um ataque básico
MULTIPLICADOR_CRITICO = 1.8        # dano crítico = dano normal * 1.8
REDUCAO_DANO_DEFENDER = 0.5        # ao defender, recebe metade do dano
DANO_MINIMO = 1                    # nunca menos que 1 de dano
CHANCE_FUGA = 0.6                  # 60% de chance de fugir com sucesso

# ----- Progressão -----
XP_BASE_POR_NIVEL = 100            # xp necessário = XP_BASE_POR_NIVEL * nivel
PONTOS_HABILIDADE_POR_NIVEL = 1

# Quanto os atributos sobem a cada level up
GANHO_VIDA_POR_NIVEL = 15
GANHO_MANA_POR_NIVEL = 8
GANHO_ATAQUE_POR_NIVEL = 3
GANHO_DEFESA_POR_NIVEL = 2

# ----- Regeneração de mana -----
REGEN_MANA_POR_TURNO = 5           # mana recuperada a cada turno de combate
