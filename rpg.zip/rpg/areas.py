"""
areas.py
========

Representa o "mapa" do jogo: quais áreas existem, quais inimigos
podem aparecer em cada uma, requisitos de desbloqueio (nível mínimo
ou ter derrotado um chefe específico) e o que acontece quando o
jogador escolhe explorar uma área (batalha, evento, chefe, ou nada).
"""

import json
import random

import config
import utils
from inimigos import inimigo_aleatorio_da_area, criar_inimigo
from combate import batalha
from eventos import evento_aleatorio


def carregar_dados_areas():
    with open(config.CAMINHO_AREAS, "r", encoding="utf-8") as arquivo:
        return json.load(arquivo)


def verificar_desbloqueios(jogador, dados_areas):
    """
    Checa todas as áreas ainda bloqueadas e desbloqueia as que já
    cumprem os requisitos (nível mínimo e/ou chefe derrotado).
    Retorna a lista de nomes de áreas recém-desbloqueadas.
    """
    novas = []
    for id_area, dados in dados_areas.items():
        if id_area in jogador.areas_desbloqueadas:
            continue

        nivel_ok = jogador.nivel >= dados.get("nivel_minimo", 1)
        chefe_requisito = dados.get("chefe_requisito")
        chefe_ok = chefe_requisito is None or chefe_requisito in jogador.chefes_derrotados

        if nivel_ok and chefe_ok:
            jogador.areas_desbloqueadas.append(id_area)
            novas.append(dados["nome"])

    return novas


def mostrar_mapa(jogador, dados_areas):
    print("\n===== MAPA =====")
    ids_areas = list(dados_areas.keys())
    for indice, id_area in enumerate(ids_areas, start=1):
        dados = dados_areas[id_area]
        if id_area in jogador.areas_desbloqueadas:
            print(f"{indice} - {dados['nome']}")
        else:
            requisito = _descrever_requisito(dados)
            print(f"{indice} - {dados['nome']} 🔒 ({requisito})")
    print(f"{len(ids_areas) + 1} - Voltar")
    return ids_areas


def _descrever_requisito(dados):
    if dados.get("chefe_requisito"):
        return f"derrote {dados['chefe_requisito']}"
    if dados.get("nivel_minimo", 1) > 1:
        return f"nível {dados['nivel_minimo']}"
    return "bloqueado"


def explorar(jogador, dados_areas, dados_inimigos, dados_habilidades, dados_itens):
    ids_areas = mostrar_mapa(jogador, dados_areas)
    escolha = utils.ler_numero("\nEscolha uma área: ", minimo=1, maximo=len(ids_areas) + 1)

    if escolha == len(ids_areas) + 1:
        return

    id_area = ids_areas[escolha - 1]
    if id_area not in jogador.areas_desbloqueadas:
        print("🔒 Essa área ainda está bloqueada.")
        return

    jogador.area_atual = id_area
    dados_area = dados_areas[id_area]
    print(f"\nVocê entrou em: {dados_area['nome']}")

    resultado = random.random()

    id_chefe = dados_area.get("chefe")
    chefe_disponivel = id_chefe is not None and id_chefe not in jogador.chefes_derrotados

    if chefe_disponivel and resultado < 0.15:
        print(f"\n👑 O chefe da área apareceu!")
        inimigo = criar_inimigo(id_chefe, dados_inimigos)
        resultado_batalha = batalha(jogador, inimigo, dados_itens, dados_habilidades, pode_fugir=False)
        return resultado_batalha

    elif resultado < 0.65:
        inimigo = inimigo_aleatorio_da_area(id_area, dados_areas, dados_inimigos)
        if inimigo is None:
            print("A área está tranquila por enquanto...")
            return
        print(f"\nUm {inimigo.nome} apareceu!")
        return batalha(jogador, inimigo, dados_itens, dados_habilidades)

    elif resultado < 0.85:
        evento_aleatorio(jogador)
        return "evento"

    else:
        print("Nada aconteceu por aqui.")
        return "nada"
