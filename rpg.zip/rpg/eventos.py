"""
eventos.py
==========

Eventos aleatórios simples que podem acontecer ao explorar uma área,
separados do combate. Nada muito elaborado — só pequenas variações
para a exploração não ser sempre "ou batalha, ou nada".
"""

import random

import utils


def evento_aleatorio(jogador):
    eventos = [_evento_bolsa_ouro, _evento_viajante, _evento_pocao_encontrada]
    evento_escolhido = random.choice(eventos)
    evento_escolhido(jogador)


def _evento_bolsa_ouro(jogador):
    print("\nVocê encontrou uma bolsa de ouro largada no chão!")
    escolha = utils.ler_opcao("1 - Pegar\n2 - Ignorar\nEscolha: ", {"1", "2"})
    if escolha == "1":
        quantidade = random.randint(10, 30)
        jogador.ganhar_ouro(quantidade)
        print(f"💰 +{quantidade} ouro")
    else:
        print("Você seguiu em frente.")


def _evento_viajante(jogador):
    print("\nVocê encontrou um viajante cansado na estrada.")
    escolha = utils.ler_opcao("1 - Conversar\n2 - Ignorar\nEscolha: ", {"1", "2"})
    if escolha == "1":
        xp = random.randint(5, 15)
        jogador.ganhar_xp(xp)
        print(f"O viajante compartilhou um conselho útil. +{xp} XP")
    else:
        print("Você seguiu em frente.")


def _evento_pocao_encontrada(jogador):
    print("\nVocê encontrou uma poção pequena escondida entre as pedras!")
    jogador.pocoes["pocao_pequena"] = jogador.pocoes.get("pocao_pequena", 0) + 1
    print("🧪 Poção pequena adicionada ao inventário.")
