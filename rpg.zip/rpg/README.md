# RPG de Turnos em Python

Um RPG de turnos para terminal, com POO, dados em JSON e sistema de
save/load, feito para praticar Python além do nível de exercício
escolar.

## Como executar

```
cd rpg
python3 main.py
```

Requer apenas Python 3 (biblioteca padrão — nenhuma dependência externa).

## Estrutura de pastas

```
rpg/
├── main.py          # ponto de entrada, coordena tudo
├── config.py        # constantes e valores de balanceamento
├── personagens.py   # classes Personagem (base) e Jogador
├── inimigos.py      # classe Inimigo + carregamento do JSON
├── combate.py       # sistema de batalha por turnos
├── habilidades.py   # habilidades e árvore de habilidades
├── loja.py          # loja, compra e equipar itens
├── areas.py         # mapa, exploração, desbloqueio de áreas
├── eventos.py       # eventos aleatórios de exploração
├── save.py          # salvar/carregar progresso (objeto <-> JSON)
├── utils.py         # barras de vida, menus, validação de input
├── dados/
│   ├── save.json         # progresso salvo (criado/atualizado pelo jogo)
│   ├── inimigos.json      # dados de todos os inimigos e chefes
│   ├── habilidades.json   # habilidades e seus pré-requisitos
│   ├── itens.json         # poções e equipamentos da loja
│   ├── classes.json       # atributos iniciais de cada classe
│   └── areas.json         # áreas, inimigos possíveis, requisitos
└── README.md
```

## Como os sistemas funcionam

### Personagens (POO)

`Personagem` é a classe base com o que é comum a todo mundo (vida,
ataque, defesa, nível, XP). `Jogador` e `Inimigo` **herdam** dela —
por isso não escrevemos "receber_dano()" duas vezes. `Jogador`
adiciona mana, poções, inventário, equipamentos e habilidades;
`Inimigo` adiciona recompensas (XP/ouro) e uma IA simples.

### Combate

`combate.py` roda um loop: mostra o status, lê a ação do jogador
(atacar / habilidade / defender / poção / fugir), aplica o efeito,
e — se o inimigo ainda estiver vivo — executa o turno dele (que
decide entre atacar ou defender olhando a própria vida). O dano usa
a fórmula `ataque - defesa + variação aleatória`, nunca menor que 1.
Crítico e erro de ataque são sorteados com `random.random()`.

### Habilidades e árvore de habilidades

Cada habilidade tem um `requisito` (outra habilidade, ou `null` se
for a primeira da árvore) e um `nivel_necessario`. `pode_desbloquear()`
verifica todas essas condições antes de liberar. Isso implementa a
árvore sem precisar de uma estrutura de dados complexa — o
"encadeamento" já está no próprio JSON.

### Loja e equipamentos

A loja lê `itens.json`, verifica se o jogador tem ouro suficiente e
move o item para o inventário. Equipar um item o move do inventário
para o slot correspondente (`arma`, `armadura`, `acessorio`) e o
bônus é somado dinamicamente ao atacar (`ataque_total()`).

### Áreas e progressão

Cada área tem uma lista de inimigos possíveis e requisitos de
desbloqueio (nível mínimo e/ou ter derrotado um chefe específico).
`verificar_desbloqueios()` roda depois de cada exploração e libera
novas áreas automaticamente quando os requisitos são cumpridos.

### Save / Load

Este é o ponto mais importante para quem está aprendendo: o módulo
`json` só entende strings, números, booleanos, listas e
dicionários — nunca objetos Python diretamente. Por isso o fluxo é:

```
objeto Jogador --jogador_para_dict()--> dicionário --json.dump()--> save.json
save.json --json.load()--> dicionário --dict_para_jogador()--> objeto Jogador
```

Erros de save (arquivo ausente ou JSON corrompido) são tratados com
`try/except`, mostrando uma mensagem amigável em vez de quebrar o jogo.

## Como adicionar coisas novas

**Novo inimigo:** adicione uma entrada em `dados/inimigos.json` com
`nome, vida, ataque, defesa, xp, ouro_min, ouro_max` e inclua o id
dele na lista `inimigos` da área desejada em `dados/areas.json`.
Não precisa mexer em nenhum arquivo `.py`.

**Novo item:** adicione uma entrada em `dados/itens.json` com
`nome, tipo (pocao/arma/armadura/acessorio), preco` e os bônus
(`bonus_ataque`, `bonus_defesa`, `bonus_critico`) se for equipamento.

**Nova habilidade:** adicione em `dados/habilidades.json` com
`classe, nivel_necessario, custo_pontos, custo_mana,
multiplicador_dano` e um `requisito` (id de outra habilidade da
árvore, ou `null`).

**Nova área:** adicione em `dados/areas.json` com `nome, inimigos`
(lista de ids), `chefe` (id ou `null`), `nivel_minimo` e
`chefe_requisito` (id de chefe que precisa ser derrotado antes, ou
`null`).

## Conceitos de Python usados

- **class / `__init__` / `self`**: `Personagem` é o "molde"; cada
  `Jogador` ou `Inimigo` criado é um objeto com seus próprios
  valores guardados em `self`.
- **Herança** (`class Jogador(Personagem)`): reaproveita código
  comum e permite sobrescrever métodos (`subir_nivel()` em `Jogador`
  chama `super().subir_nivel()` e depois adiciona mana e pontos de
  habilidade).
- **Módulos e `import`**: cada arquivo cuida de uma responsabilidade;
  `main.py` importa e coordena os outros.
- **JSON** (`json.load()` / `json.dump()` / `with open(...)`): forma
  de guardar dados fora do código e persistir o progresso.
- **Listas e dicionários**: inventário, poções e inimigos possíveis
  por área usam essas estruturas.
- **`while` / `for` / `if/elif/else`**: loops de combate e de menu,
  decisões de IA simples do inimigo.
- **`random`**: variação de dano, chance de crítico/erro/fuga,
  sorteio de inimigo e evento.

Não foram usados decorators, dataclasses, enums ou exceções
personalizadas — o projeto usa `try/except` apenas para tratar
erros de arquivo/JSON, mantendo o código no nível de quem está
aprendendo POO básica.

## O que testar

- Criar personagem com nome vazio → deve pedir de novo
- Escolher cada uma das 3 classes e comparar atributos
- Atacar, defender, usar poção sem ter poção, usar habilidade sem mana
- Derrotar um inimigo comum e verificar XP/ouro/level up
- Comprar item sem ouro suficiente
- Equipar uma arma e conferir se o ataque total mudou
- Desbloquear uma habilidade sem ter a anterior (deve bloquear)
- Enfrentar o Rei Goblin na Floresta e depois checar se a Caverna desbloqueou
- Salvar, sair e carregar o jogo — conferir se tudo voltou igual
- Corromper `dados/save.json` manualmente e tentar carregar (não deve quebrar)
