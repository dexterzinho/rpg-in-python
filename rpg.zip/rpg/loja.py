"""
loja.py
=======

Menu da loja: mostra os itens disponíveis (lidos de dados/itens.json),
processa a compra (checando se o jogador tem ouro suficiente) e
atualiza o inventário/equipamentos do jogador.
"""

import json

import config
import utils


def carregar_dados_itens():
    with open(config.CAMINHO_ITENS, "r", encoding="utf-8") as arquivo:
        return json.load(arquivo)


def abrir_loja(jogador, dados_itens):
    while True:
        print("\n===== LOJA =====")
        print(f"Ouro: {jogador.ouro}")

        ids_itens = list(dados_itens.keys())
        for indice, id_item in enumerate(ids_itens, start=1):
            item = dados_itens[id_item]
            print(f"{indice} - {item['nome']} ...... {item['preco']} ouro")
        print(f"{len(ids_itens) + 1} - Sair")

        escolha = utils.ler_numero("\nEscolha: ", minimo=1, maximo=len(ids_itens) + 1)
        if escolha == len(ids_itens) + 1:
            break

        id_escolhido = ids_itens[escolha - 1]
        comprar_item(jogador, id_escolhido, dados_itens)


def comprar_item(jogador, id_item, dados_itens):
    item = dados_itens[id_item]

    if not jogador.gastar_ouro(item["preco"]):
        print("❌ Ouro insuficiente.")
        return

    tipo = item["tipo"]

    if tipo == "pocao":
        jogador.pocoes[id_item] = jogador.pocoes.get(id_item, 0) + 1
    elif tipo in ("arma", "armadura", "acessorio"):
        jogador.inventario[id_item] = jogador.inventario.get(id_item, 0) + 1
    else:
        jogador.inventario[id_item] = jogador.inventario.get(id_item, 0) + 1

    print("✅ Compra realizada!")


def equipar_item(jogador, id_item, dados_itens):
    """Move um item de equipamento do inventário para o slot correspondente."""
    if jogador.inventario.get(id_item, 0) <= 0:
        return False, "Você não possui esse item."

    item = dados_itens[id_item]
    slot = item["tipo"]  # "arma", "armadura" ou "acessorio"
    if slot not in jogador.equipamentos:
        return False, "Esse item não pode ser equipado."

    # devolve o item antigo do slot para o inventário, se houver
    item_antigo = jogador.equipamentos[slot]
    if item_antigo:
        jogador.inventario[item_antigo] = jogador.inventario.get(item_antigo, 0) + 1

    jogador.inventario[id_item] -= 1
    if jogador.inventario[id_item] <= 0:
        del jogador.inventario[id_item]

    jogador.equipamentos[slot] = id_item
    return True, f"{item['nome']} equipado!"
