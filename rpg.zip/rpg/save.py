"""
save.py
=======

Tudo relacionado a SALVAR e CARREGAR o progresso.

O ponto importante deste arquivo: nunca salvamos um objeto Python
diretamente no JSON — o módulo `json` só entende strings, números,
booleanos, listas e dicionários. Por isso o fluxo é sempre:

    objeto Jogador  --jogador_para_dict()-->  dicionário
    dicionário      --json.dump()-->          save.json (arquivo)

E, ao carregar, o caminho inverso:

    save.json   --json.load()-->              dicionário
    dicionário  --dict_para_jogador()-->       objeto Jogador de novo

CONCEITOS:
- `with open(...) as arquivo:` abre um arquivo e garante que ele
  será fechado automaticamente no final do bloco, mesmo se der erro.
- `json.dump(dado, arquivo)` escreve um dicionário Python como JSON.
- `json.load(arquivo)` lê um JSON e devolve um dicionário Python.
"""

import json
import os

import config
from personagens import Jogador


def existe_save():
    return os.path.exists(config.CAMINHO_SAVE) and os.path.getsize(config.CAMINHO_SAVE) > 2


def jogador_para_dict(jogador):
    """Converte o objeto Jogador em um dicionário só com dados simples."""
    return {
        "nome": jogador.nome,
        "classe": jogador.classe,
        "nivel": jogador.nivel,
        "xp": jogador.xp,
        "xp_necessario": jogador.xp_necessario,
        "vida": jogador.vida,
        "vida_maxima": jogador.vida_maxima,
        "ataque": jogador.ataque,
        "defesa": jogador.defesa,
        "mana": jogador.mana,
        "mana_maxima": jogador.mana_maxima,
        "chance_critico": jogador.chance_critico,
        "ouro": jogador.ouro,
        "pontos_habilidade": jogador.pontos_habilidade,
        "habilidades_desbloqueadas": jogador.habilidades_desbloqueadas,
        "pocoes": jogador.pocoes,
        "inventario": jogador.inventario,
        "equipamentos": jogador.equipamentos,
        "area_atual": jogador.area_atual,
        "areas_desbloqueadas": jogador.areas_desbloqueadas,
        "chefes_derrotados": jogador.chefes_derrotados,
    }


def dict_para_jogador(dados):
    """Reconstrói um objeto Jogador a partir do dicionário lido do JSON."""
    dados_classe_falsos = {
        "nome": dados["classe"],
        "vida": dados["vida_maxima"],
        "ataque": dados["ataque"],
        "defesa": dados["defesa"],
        "mana": dados["mana_maxima"],
        "chance_critico": dados["chance_critico"],
    }
    jogador = Jogador(dados["nome"], dados_classe_falsos)

    jogador.nivel = dados["nivel"]
    jogador.xp = dados["xp"]
    jogador.xp_necessario = dados["xp_necessario"]
    jogador.vida = dados["vida"]
    jogador.mana = dados["mana"]
    jogador.ouro = dados["ouro"]
    jogador.pontos_habilidade = dados["pontos_habilidade"]
    jogador.habilidades_desbloqueadas = dados["habilidades_desbloqueadas"]
    jogador.pocoes = dados["pocoes"]
    jogador.inventario = dados["inventario"]
    jogador.equipamentos = dados["equipamentos"]
    jogador.area_atual = dados["area_atual"]
    jogador.areas_desbloqueadas = dados["areas_desbloqueadas"]
    jogador.chefes_derrotados = dados["chefes_derrotados"]

    return jogador


def salvar_jogo(jogador):
    dados = jogador_para_dict(jogador)
    try:
        with open(config.CAMINHO_SAVE, "w", encoding="utf-8") as arquivo:
            json.dump(dados, arquivo, indent=2, ensure_ascii=False)
        return True
    except OSError:
        print("❌ Não foi possível salvar o jogo.")
        return False


def carregar_jogo():
    """
    Retorna o objeto Jogador reconstruído, ou None se não houver save
    válido (arquivo inexistente, JSON corrompido ou faltando dados).
    """
    if not existe_save():
        return None

    try:
        with open(config.CAMINHO_SAVE, "r", encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
        return dict_para_jogador(dados)
    except (json.JSONDecodeError, OSError, KeyError):
        print("⚠️ O arquivo de save está corrompido ou incompleto.")
        return None
