"""
inimigos.py
===========

Classe Inimigo (também herda de Personagem, igual o Jogador) e as
funções que leem dados/inimigos.json e transformam cada entrada em
um objeto Inimigo de verdade.

Por que carregar de JSON em vez de escrever "Goblin = Inimigo(...)"
direto no código? Porque assim, para adicionar um inimigo novo,
basta editar o arquivo JSON — sem precisar mexer no código Python.
"""

import json
import random

import config
from personagens import Personagem


class Inimigo(Personagem):
    """Inimigo herda vida/ataque/defesa/dano de Personagem e adiciona
    o que só faz sentido para inimigos: recompensas e comportamento."""

    def __init__(self, id_inimigo, dados):
        super().__init__(
            nome=dados["nome"],
            vida_maxima=dados["vida"],
            ataque=dados["ataque"],
            defesa=dados["defesa"],
            nivel=dados.get("nivel", 1),
        )
        self.id = id_inimigo
        self.xp_concedido = dados["xp"]
        self.ouro_min = dados["ouro_min"]
        self.ouro_max = dados["ouro_max"]
        self.eh_chefe = dados.get("chefe", False)
        self.chance_critico = dados.get("chance_critico", 0.05)

    def ouro_sorteado(self):
        return random.randint(self.ouro_min, self.ouro_max)

    def decidir_acao(self):
        """
        IA simples do inimigo: decide entre "atacar" e "defender"
        olhando a própria vida. Não é uma IA "esperta" de verdade —
        é só uma regra simples para o combate não ficar sempre igual.
        """
        percentual_vida = self.vida / self.vida_maxima
        if percentual_vida < 0.25 and random.random() < 0.4:
            return "defender"
        return "atacar"


def carregar_dados_inimigos():
    """Lê dados/inimigos.json e retorna o dicionário bruto."""
    with open(config.CAMINHO_INIMIGOS, "r", encoding="utf-8") as arquivo:
        return json.load(arquivo)


def criar_inimigo(id_inimigo, dados_inimigos=None):
    """Cria um objeto Inimigo a partir do seu id (ex: 'goblin')."""
    if dados_inimigos is None:
        dados_inimigos = carregar_dados_inimigos()
    dados = dados_inimigos[id_inimigo]
    return Inimigo(id_inimigo, dados)


def inimigo_aleatorio_da_area(id_area, dados_areas, dados_inimigos):
    """
    Sorteia um inimigo comum entre os possíveis para a área informada.
    Retorna None se a área não tiver inimigos cadastrados.
    """
    possiveis = dados_areas[id_area].get("inimigos", [])
    if not possiveis:
        return None
    id_escolhido = random.choice(possiveis)
    return criar_inimigo(id_escolhido, dados_inimigos)
