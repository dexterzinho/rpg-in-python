"""
utils.py
========

Funções auxiliares reutilizadas em vários lugares do jogo. Nada de
lógica de jogo aqui — só "ferramentas" genéricas de exibição e
leitura de input, para não repetir o mesmo código de validação em
combate.py, loja.py, areas.py, etc.
"""


def barra_vida(atual, maximo, tamanho=10, emoji="❤️"):
    """
    Monta uma barra de vida como: ❤️ ███████░░░ 70/100
    Calculada dinamicamente a partir dos valores atuais — nunca com
    números fixos, então funciona para qualquer vida/vida_maxima.
    """
    atual = max(atual, 0)
    proporcao = atual / maximo if maximo > 0 else 0
    preenchido = round(proporcao * tamanho)
    vazio = tamanho - preenchido
    return f"{emoji} {'█' * preenchido}{'░' * vazio} {atual}/{maximo}"


def separador(caractere="=", tamanho=40):
    print(caractere * tamanho)


def titulo(texto):
    separador()
    print(texto)
    separador()


def ler_opcao(prompt, opcoes_validas):
    """
    Lê uma opção de menu (string) do usuário e só aceita se estiver
    dentro de `opcoes_validas`. Nunca deixa o programa quebrar por
    causa de um input inesperado — sempre pede de novo.
    """
    while True:
        escolha = input(prompt).strip()
        if escolha in opcoes_validas:
            return escolha
        print("❌ Opção inválida.")


def ler_numero(prompt, minimo=None, maximo=None):
    """Lê um número inteiro do usuário, validando o formato e o intervalo."""
    while True:
        texto = input(prompt).strip()
        if not texto.lstrip("-").isdigit():
            print("❌ Digite um número válido.")
            continue
        numero = int(texto)
        if minimo is not None and numero < minimo:
            print(f"❌ O valor mínimo é {minimo}.")
            continue
        if maximo is not None and numero > maximo:
            print(f"❌ O valor máximo é {maximo}.")
            continue
        return numero


def ler_texto_nao_vazio(prompt):
    """Repete a pergunta até o usuário digitar algo diferente de vazio."""
    while True:
        texto = input(prompt).strip()
        if texto:
            return texto
        print("❌ Esse campo não pode ficar vazio.")


def pausar():
    input("\n(pressione Enter para continuar) ")
