"""
habilidades.py
==============

Sistema de habilidades: carrega dados/habilidades.json, decide quais
habilidades cada classe pode usar, controla a árvore de pré-requisitos
(não dá pra pegar uma habilidade avançada sem ter a anterior) e aplica
o efeito de uma habilidade em combate.

Cada habilidade no JSON tem:
    nome, descricao, classe, nivel_necessario, custo_pontos,
    custo_mana, multiplicador_dano, requisito (id de outra habilidade
    ou null se for a primeira da árvore)
"""

import json

import config


def carregar_dados_habilidades():
    with open(config.CAMINHO_HABILIDADES, "r", encoding="utf-8") as arquivo:
        return json.load(arquivo)


def habilidades_da_classe(classe, dados_habilidades):
    """Retorna {id: dados} só das habilidades daquela classe."""
    return {
        id_hab: dados
        for id_hab, dados in dados_habilidades.items()
        if dados["classe"] == classe
    }


def pode_desbloquear(jogador, id_habilidade, dados_habilidades):
    """
    Verifica se o jogador cumpre os requisitos para desbloquear uma
    habilidade: nível mínimo, pontos de habilidade suficientes, e
    (se houver) já ter desbloqueado a habilidade-requisito anterior.
    """
    dados = dados_habilidades[id_habilidade]

    if id_habilidade in jogador.habilidades_desbloqueadas:
        return False, "Você já possui essa habilidade."
    if jogador.nivel < dados["nivel_necessario"]:
        return False, f"Requer nível {dados['nivel_necessario']}."
    if jogador.pontos_habilidade < dados["custo_pontos"]:
        return False, "Pontos de habilidade insuficientes."

    requisito = dados.get("requisito")
    if requisito and requisito not in jogador.habilidades_desbloqueadas:
        nome_requisito = dados_habilidades[requisito]["nome"]
        return False, f"Requer a habilidade '{nome_requisito}' primeiro."

    return True, ""


def desbloquear_habilidade(jogador, id_habilidade, dados_habilidades):
    liberado, motivo = pode_desbloquear(jogador, id_habilidade, dados_habilidades)
    if not liberado:
        return False, motivo

    dados = dados_habilidades[id_habilidade]
    jogador.pontos_habilidade -= dados["custo_pontos"]
    jogador.habilidades_desbloqueadas.append(id_habilidade)
    return True, f"Habilidade '{dados['nome']}' desbloqueada!"


def usar_habilidade(jogador, id_habilidade, alvo, dados_habilidades):
    """
    Aplica o efeito de uma habilidade já desbloqueada sobre um alvo
    em combate. Retorna (sucesso, mensagem, dano_causado).
    """
    if id_habilidade not in jogador.habilidades_desbloqueadas:
        return False, "Você não possui essa habilidade.", 0

    dados = dados_habilidades[id_habilidade]
    custo_mana = dados.get("custo_mana", 0)

    if custo_mana > jogador.mana:
        return False, "Mana insuficiente!", 0

    jogador.mana -= custo_mana
    dano = jogador.calcular_dano(alvo, bonus_dano=dados.get("bonus_dano", 0))
    dano = int(dano * dados.get("multiplicador_dano", 1.0))
    alvo.receber_dano(dano)

    return True, f"Você usou {dados['nome']}!", dano


def mostrar_arvore_habilidades(jogador, dados_habilidades):
    """Imprime a árvore de habilidades da classe do jogador no terminal."""
    habilidades = habilidades_da_classe(jogador.classe, dados_habilidades)

    print("\n===== ÁRVORE DE HABILIDADES =====")
    for id_hab, dados in habilidades.items():
        if id_hab in jogador.habilidades_desbloqueadas:
            marcador = "[x]"
        else:
            liberado, _ = pode_desbloquear(jogador, id_hab, dados_habilidades)
            marcador = "[ ]" if liberado else "[ ] (bloqueado)"
        print(f"{marcador} {dados['nome']} - {dados['descricao']}")
    print(f"\nPontos disponíveis: {jogador.pontos_habilidade}")
